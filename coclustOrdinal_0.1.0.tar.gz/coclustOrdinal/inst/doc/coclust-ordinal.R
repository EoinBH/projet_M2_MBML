## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>",
                      fig.width = 6.5, fig.height = 4, fig.align = "center")
library(coclustOrdinal)

## ----quick--------------------------------------------------------------------
sim <- simulate_cub_lbm(n = 100, d = 50, m = 5, seed = 1)
fit <- coclust_ordinal(sim$X, K = 2, L = 2, seed = 1)
fit

## ----cub-shapes, fig.height = 3.2---------------------------------------------
dcub <- function(m, pi, xi) {
  r <- 1:m
  pi * choose(m - 1, r - 1) * xi^(m - r) * (1 - xi)^(r - 1) + (1 - pi) / m
}
op <- par(mfrow = c(1, 3), mar = c(4, 4, 3, 1))
barplot(dcub(7, 0.9, 0.2), names.arg = 1:7, ylim = c(0, 0.45),
        main = "pi = 0.9, xi = 0.2", xlab = "answer", ylab = "probability")
barplot(dcub(7, 0.9, 0.8), names.arg = 1:7, ylim = c(0, 0.45),
        main = "pi = 0.9, xi = 0.8", xlab = "answer")
barplot(dcub(7, 0.3, 0.8), names.arg = 1:7, ylim = c(0, 0.45),
        main = "pi = 0.3, xi = 0.8", xlab = "answer")
par(op)

## ----sim-hard-----------------------------------------------------------------
pi_true <- matrix(c(0.8, 0.6, 0.7,
                    0.7, 0.8, 0.6), nrow = 3, ncol = 2)
xi_true <- matrix(c(0.3, 0.7, 0.5,
                    0.7, 0.4, 0.2), nrow = 3, ncol = 2)
sim <- simulate_cub_lbm(n = 150, d = 40, m = 7,
                        alpha = c(0.5, 0.3, 0.2), beta = c(0.6, 0.4),
                        pi = pi_true, xi = xi_true, seed = 3)
X <- sim$X
X[1:5, 1:10]

## ----heat-raw, fig.height = 3.6-----------------------------------------------
plot_ordinal <- function(X, main = "", row_breaks = NULL, col_breaks = NULL) {
  m <- max(X)
  image(1:ncol(X), 1:nrow(X), t(X[nrow(X):1, ]), col = hcl.colors(m, "viridis"),
        xlab = "columns (questions)", ylab = "rows (respondents)",
        main = main, axes = FALSE)
  abline(h = nrow(X) - row_breaks + 0.5, v = col_breaks + 0.5,
         col = "white", lwd = 2)
}
plot_ordinal(X, main = "Raw data")

## ----fit-hard-----------------------------------------------------------------
fit <- coclust_ordinal(X, K = 3, L = 2, seed = 1)
summary(fit)

## ----compare------------------------------------------------------------------
table(estimated = fit$row_clusters, true = sim$z)
table(estimated = fit$col_clusters, true = sim$w)
if (requireNamespace("mclust", quietly = TRUE)) {
  c(rows = mclust::adjustedRandIndex(fit$row_clusters, sim$z),
    columns = mclust::adjustedRandIndex(fit$col_clusters, sim$w))
}

## ----params-------------------------------------------------------------------
row_match <- apply(table(fit$row_clusters, sim$z), 2, which.max)
col_match <- apply(table(fit$col_clusters, sim$w), 2, which.max)
round(fit$params$pi[row_match, col_match], 2)   # true: pi_true
round(fit$params$xi[row_match, col_match], 2)   # true: xi_true

## ----heat-sorted, fig.height = 3.6--------------------------------------------
ro <- order(fit$row_clusters)
co <- order(fit$col_clusters)
plot_ordinal(X[ro, co], main = "Data sorted by estimated clusters",
             row_breaks = cumsum(table(fit$row_clusters))[-fit$K],
             col_breaks = cumsum(table(fit$col_clusters))[-fit$L])

## ----probs--------------------------------------------------------------------
round(head(fit$row_prob), 2)
max_prob <- apply(fit$row_prob, 1, max)
summary(max_prob)
round(fit$row_prob[max_prob < 0.9, , drop = FALSE], 2)

## ----select-------------------------------------------------------------------
sel <- coclust_ordinal_select(X, K_range = 1:4, L_range = 1:3,
                              n_init = 3, seed = 1)
sel$table[order(-sel$table$icl), ][1:5, ]

## ----icl-grid, fig.height = 3.4-----------------------------------------------
icl_mat <- xtabs(icl ~ K + L, data = sel$table)
matplot(as.numeric(rownames(icl_mat)), icl_mat, type = "b", pch = 19,
        lty = 1, col = 1:3, xlab = "K (row clusters)", ylab = "ICL",
        main = "ICL for each (K, L)", xaxt = "n")
axis(1, at = as.numeric(rownames(icl_mat)))
legend("bottomright", legend = paste("L =", colnames(icl_mat)),
       col = 1:3, pch = 19, lty = 1, bty = "n")

